Controls

Q - Previous Cup

E - Next Cup

F - Drink


Commands

setCaff int

clearCup void

addBrew typeid1 typeid2 meanpurity

addBean // No Use yet

currDrink // self explanatory

SetEffect // Add Effect

New: 

Added Powerup GUI

Powerup Cmds

Added Drinking 


Synopsis :

Quake And Coffee is a mod where your health is replaced by a draining resource known as Caffeine. With this new health resource comes enemies that drop beans to be made into special, new weapons, and new Poweruffs and debuffs to add challenge as well as a brewing minigame for making each coffee